$ opt -load ./LLVM_bkl_pass.so -bbloop -disable-output -time-passes loop.bc
