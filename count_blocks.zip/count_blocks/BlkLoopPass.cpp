#define DEBUG_TYPE "BlkLoopPass" 

#include <llvm/Pass.h>
#include <llvm/IR/Function.h> 
#include <llvm/Analysis/LoopInfo.h>
#include <llvm/Support/raw_ostream.h> 

#include <llvm/ADT/Statistic.h>
#include <llvm/IR/InstIterator.h>
#include <llvm/IR/Instructions.h>
#include <llvm/Analysis/LoopInfo.h>


#include <map>
#include <vector>
#include <iostream>

using namespace llvm;
using namespace std;

namespace{
	struct	BlkLoppPass : public FunctionPass{
		static	char ID;
		BlkLoppPass():FunctionPass(ID){}
		
		virtual	bool runOnFunction(Function &F){
            int ans = 0;
			for(Function::iterator b = F.begin(); b != F.end(); b++){
                ans++;
                errs() << *b << "\n";
            }
            errs() << ans << "\n";
		    return false;
		}
	};
}

char BlkLoppPass::ID = 0; static RegisterPass<BlkLoppPass> X("bbloop", "Count the number of BBs inside each loop");
